// Example backend for Tahadi Sahra. Node.js 18+
// Keep your API key on the server; never put it in the HTML file.
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/generate", async (req, res) => {
  try {
    const { players = [], difficulty = "متنوعة", source = "internet_ai" } = req.body;
    if (!Array.isArray(players) || players.length === 0) {
      return res.status(400).json({ error: "أضف مشاركًا واحدًا على الأقل." });
    }
    const prompt = `
أنت محرر أسئلة مسابقات رياضية باللغة العربية. أنشئ 6 أسئلة لكل مشارك، سؤالًا عن كل خانة متوفرة من: النادي المفضل، المنتخب المفضل، النادي الذي لا يشجعه، المنتخب الذي لا يشجعه، الرياضة المفضلة، الرياضة غير المفضلة.
المستوى: ${difficulty}. أخرج JSON فقط بالشكل {"questions":[{"playerName":"...","topic":"...","question":"...","answer":"...","explanation":"..."}]}.
يجب أن يكون لكل سؤال جواب محدد قابل للتحقق، وألا تخترع حقائق. تجنب الأسئلة المبهمة أو التي تعتمد على رأي الشخص. إذا كانت المعلومة حديثة أو قد تتغير، اذكر ذلك في explanation وتحقق من المصدر عند توفر أداة بحث. لا تدّعِ أنك بحثت على الإنترنت إذا لم تتوفر أداة بحث.
بيانات المشاركين:
${JSON.stringify(players)}
مصدر التفضيل المطلوب: ${source}.
`;
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      tools: source === "internet_ai" ? [{ type: "web_search" }] : undefined,
      input: prompt
    });
    const text = response.output_text || "";
    const start = text.indexOf("{"), end = text.lastIndexOf("}");
    if (start < 0 || end < start) throw new Error("لم يرجع النموذج JSON صالحًا.");
    const parsed = JSON.parse(text.slice(start, end + 1));
    if (!Array.isArray(parsed.questions)) throw new Error("صيغة الأسئلة غير صالحة.");
    res.json(parsed);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "تعذر توليد الأسئلة. راجع إعدادات الخادم ومفتاح API." });
  }
});

app.post("/api/one-question", async (req, res) => {
  try {
    const { topic, difficulty = "متنوعة" } = req.body;
    if (!topic) return res.status(400).json({ error: "الموضوع مطلوب." });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      tools: [{ type: "web_search" }],
      input: `أنشئ سؤال مسابقات رياضية واحدًا باللغة العربية عن ${topic} بمستوى ${difficulty}. يجب أن تكون الإجابة محددة وقابلة للتحقق. أخرج JSON فقط بالشكل {"question":"...","answer":"...","explanation":"..."}. لا تدّعِ البحث على الإنترنت إذا لم تستخدم أداة بحث.`
    });
    const text = response.output_text || "";
    const start = text.indexOf("{"), end = text.lastIndexOf("}");
    if (start < 0 || end < start) throw new Error("صيغة غير صالحة");
    res.json(JSON.parse(text.slice(start, end + 1)));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "تعذر توليد السؤال." });
  }
});

app.listen(port, () => console.log(`Tahadi Sahra running on http://localhost:${port}`));
